# \[ 🚧 Work in progress 👷‍♀️⛏👷🔧 🚧 \] GoGrocery 2.0 

## GoGrocery 1.0
**Attention :** This version/branch of app has now been deprecated, Check for other branches
##### Its an eCommerce app inspired from Amazon, big Basket, Grofers, Flipkart Etc


### Connect with me 
[![Linkedin](https://img.shields.io/badge/-Adarsh%20Sahu-blue?style=flat-square&logo=linkedin&logoColor=white&link=https://www.linkedin.com/in/sahuadarsh0/)](https://www.linkedin.com/in/sahuadarsh0/)
[![Gmail](https://img.shields.io/badge/-sahuadarsh0@gmail.com-gray?style=flat-square&logo=gmail&logoColor=red&link=)](mailto:sahuadarsh0@gmail.com)
[![Technited Minds](https://img.shields.io/badge/-Technited%20Minds-blue?style=flat-square&logoColor=white&link=http://www.technitedminds.com/)](http://www.technitedminds.com/)

### Download and install the ![APP](https://github.com/sahuadarsh0/GoGrocery/blob/master/app.apk?raw=true)
##### See screenshots for better visuals

![1st](https://raw.githubusercontent.com/sahuadarsh0/GoGrocery/master/screenshots/screenshot-1523923061244.jpg) ![2nd](https://raw.githubusercontent.com/sahuadarsh0/GoGrocery/master/screenshots/screenshot-1523923168107.jpg)       ![3rd](https://raw.githubusercontent.com/sahuadarsh0/GoGrocery/master/screenshots/screenshot-1523923186122.jpg)       ![4th](https://raw.githubusercontent.com/sahuadarsh0/GoGrocery/master/screenshots/screenshot-1523923200012.jpg)       ![5th](https://raw.githubusercontent.com/sahuadarsh0/GoGrocery/master/screenshots/screenshot-1523923214915.jpg)       ![6th](https://raw.githubusercontent.com/sahuadarsh0/GoGrocery/master/screenshots/screenshot-1523923224395.jpg)       ![7th](https://raw.githubusercontent.com/sahuadarsh0/GoGrocery/master/screenshots/screenshot-1523923250045.jpg)       ![8th](https://raw.githubusercontent.com/sahuadarsh0/GoGrocery/master/screenshots/screenshot-1523923260779.jpg)       ![9th](https://raw.githubusercontent.com/sahuadarsh0/GoGrocery/master/screenshots/screenshot-1523923267733.jpg)       ![10th](https://raw.githubusercontent.com/sahuadarsh0/GoGrocery/master/screenshots/screenshot-1523923302178.jpg)       ![11th](https://raw.githubusercontent.com/sahuadarsh0/GoGrocery/master/screenshots/screenshot-1523923346923.jpg)       ![12th](https://raw.githubusercontent.com/sahuadarsh0/GoGrocery/master/screenshots/screenshot-1523923356720.jpg)       ![13th](https://raw.githubusercontent.com/sahuadarsh0/GoGrocery/master/screenshots/screenshot-1523923378147.jpg)       ![14th](https://raw.githubusercontent.com/sahuadarsh0/GoGrocery/master/screenshots/screenshot-1523923395355.jpg)       ![15th](https://raw.githubusercontent.com/sahuadarsh0/GoGrocery/master/screenshots/screenshot-1523923402620.jpg)       ![16th](https://raw.githubusercontent.com/sahuadarsh0/GoGrocery/master/screenshots/screenshot-1523923410699.jpg)       ![17th](https://raw.githubusercontent.com/sahuadarsh0/GoGrocery/master/screenshots/screenshot-1523923425164.jpg)       ![18th](https://raw.githubusercontent.com/sahuadarsh0/GoGrocery/master/screenshots/screenshot-1523923443554.jpg)


